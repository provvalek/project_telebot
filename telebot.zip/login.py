import telebot
from telebot import types
import config
import database
import delete
import edit
import friends

count = 1
code_names = []

# вся информация про пользователя
class User:
    def __init__(self, name):
        self.name = name
        self.code = ''
        self.status = ''
        self.interests = {}
        self.comment = ''
        self.interests_list = []
        self.blacklist = []
        self.favorites = []
        self.username = ''


@config.bot.message_handler(commands=['start'])
def send_welcome(message):
    # клавиаура под полем для ввода сообщения
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    item1 = types.KeyboardButton('Пройти регистрацию')
    item2 = types.KeyboardButton('У меня уже есть анкета')
    markup.add(item1, item2)
    msg = config.bot.send_message(message.chat.id, '''Приветики!
    Я <b>{0.first_name}</b>, который познакомит вас с вашими будущими друзьями!
    Если вы хотите этого, то прошу создавать анкету!'''.format(config.bot.get_me()), parse_mode='html', reply_markup=markup)
    # переход на следующую функцию
    config.bot.register_next_step_handler(msg, process_registration_step)

def process_registration_step(message):
    if message.text == 'Пройти регистрацию':
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        item = types.KeyboardButton('У меня уже есть анкета')
        markup.add(item)
        msg = config.bot.send_message(message.chat.id, 'Тогда начнём. Введите свои имя и фамилию именно в таком порядке.', parse_mode='html', reply_markup=markup)
        config.bot.register_next_step_handler(msg, process_name_step)
    elif message.text == 'У меня уже есть анкета':
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        item1 = types.KeyboardButton('Найти совпадения')
        item2 = types.KeyboardButton('Редактировать анкету')
        item3 = types.KeyboardButton('Удалить анкету')
        item4 = types.KeyboardButton('Найти профиль')
        item4 = types.KeyboardButton('Добавить профиль в чёрный список')
        item5 = types.KeyboardButton('Удалить профиль из чёрного списка')
        item6 = types.KeyboardButton('Посмотреть взаимные избрания')
        markup.add(item1, item2, item3, item4, item5, item6)
        msg = config.bot.send_message(message.chat.id, 'Ох, в таком случае я очень рад видеть вас снова! Что вы хотели бы сделать?', parse_mode='html', reply_markup=markup)
        config.bot.register_next_step_handler(msg, next_step)
    else:
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        item1 = types.KeyboardButton('Пройти регистрацию')
        item2 = types.KeyboardButton('У меня уже есть анкета')
        markup.add(item1, item2)
        msg = config.bot.send_message(message.chat.id, '''Я не уверен, что понял, что вы написали.
        Если вы хотите зарегистрироваться, нажмите на кнопку под вводом сообщения или напишите "Пройти регистрацию".
        Если у вас есть анкета, нажмите на кнопку под вводом сообщения или напишите "У меня есть анкета".''', parse_mode='html',  reply_markup=markup)
        config.bot.register_next_step_handler(msg, process_registration_step)

def process_name_step(message):
    try:
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        item = types.KeyboardButton('У меня уже есть анкета')
        markup.add(item)
        if message.text == 'У меня уже есть анкета':
            already_have(message)
        else:
            if message.text.count(' ') == 0:
                # проверка на наличие имени и фамилии
                raise Exception
            # добавление пользователя в словарь пользователей
            config.user_data[message.from_user.id] = User(message.text)
            msg = config.bot.send_message(message.chat.id, '''Введите своё кодовое имя. Оно может быть каким угодно, но самое главное - оно должно быть уникальным!
            ВНИМАНИЕ! Кодовое слово редактировать нельзя!''', parse_mode='html', reply_markup=markup)
            config.bot.register_next_step_handler(msg, process_code_step)
    except Exception:
        msg = config.bot.send_message(message.chat.id, 'Что-то пошло не так... Попробуйте снова.', parse_mode='html', reply_markup=markup)
        config.bot.register_next_step_handler(msg, process_name_step)
    
def process_code_step(message):
    try:
        global code_names
        if message.text == 'У меня уже есть анкета':
            already_have(message)
        else:
            # на случай промаха пользователя
            markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
            item = types.KeyboardButton('У меня уже есть анкета')
            markup.add(item)

            # проверка на уникальность
            if message.text in code_names:
                raise Exception
            code_names.append(message.text)
            user = config.user_data[message.from_user.id]
            # тут добавление username и кодового имени
            user.username = '{0.username}'.format(message.from_user)
            user.code = message.text    
            msg = config.bot.send_message(message.chat.id, 'Введите свой статус. Он может быть каким угодно, всё зависит от вашей фантазии: маг, ведьма, учитель, повелитель мира...', parse_mode='html', reply_markup=markup)
            config.bot.register_next_step_handler(msg, process_status_step)
    except Exception:
        # на случай промаха пользователя
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        item = types.KeyboardButton('У меня уже есть анкета')
        markup.add(item)
        msg = config.bot.send_message(message.chat.id, 'Это кодовое имя недоступно, придумайте другое.', parse_mode='html', reply_markup=markup)
        config.bot.register_next_step_handler(msg, process_code_step)

def process_status_step(message):
    try:
        if message.text == 'У меня уже есть анкета':
            already_have(message)
        else:
            # на случай промаха пользователя
            markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
            item = types.KeyboardButton('У меня уже есть анкета')
            markup.add(item)

            user = config.user_data[message.from_user.id]
            user.status = message.text        
            msg = config.bot.send_message(message.chat.id, '''Перейдём к основной части - вашим интересам. Начнём с фильмов.
            Напишите полные названия ваших любимых фильмов через запятую в кавычках. Если вы не хотите ничего указывать, напишите "-".''', parse_mode='html', reply_markup=markup)
            config.bot.register_next_step_handler(msg, process_interests_step)
    except Exception:
        # на случай промаха пользователя
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        item = types.KeyboardButton('У меня уже есть анкета')
        markup.add(item)
        msg = config.bot.send_message(message.chat.id, 'Что-то пошло не так... Перепроверьте написание и попробуйте снова.', parse_mode='html', reply_markup=markup)
        config.bot.register_next_step_handler(msg, process_status_step)

def process_interests_step(message):
    try:
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        item = types.KeyboardButton('У меня уже есть анкета')
        markup.add(item)
        types = ['films', 'tv_shows', 'books', 'cartoons', 'anime', 'singers']
        if message.text == 'У меня уже есть анкета':
            already_have(message)
        else:
            global count
            user_id = message.from_user.id 
            user = config.user_data[user_id]
            # проверка на наличие запятых в коде
            if ', '.count(message.text) != 0:
                user.interests[types[count - 1]] = message.text.split(', ')
            else:
                user.interests[types[count - 1]] = message.text
            # проверка на кавычки
            if count < 5:
                for i in message.text.split(', '):
                    if i.count('"') != 2 and i != '-':
                        raise Exception
            names_of_interests = ['', 'сериалов', '', 'мультфильмов', 'аниме']
            # так сделано, потому что в случае с книгами и музыкальными исполнителями сообщение другое писать надо
            if count != 5 and count != 2 and count != 6:
                name_of_interest = names_of_interests[count]
                count += 1
                msg = config.bot.send_message(message.chat.id, 'Теперь точно так же напиши полные названия твоих любимых {} через запятую в кавычках. Если вы не хотите ничего указывать, напишите "-".'.format(name_of_interest), parse_mode='html', reply_markup=markup)
                config.bot.register_next_step_handler(msg, process_interests_step)
            elif count == 5:
                msg = config.bot.send_message(message.chat.id, '''Теперь точно так же напиши псевдонимы твоих любимых музыкальных исполнителей или названия твоих любимых музыкальных групп через запятую.
                Примечание: писать нужно самый популярный псевдоним или название. Например, Halsey, Little Big и тому подобное. Если вы не хотите ничего указывать, напишите "-".''', parse_mode='html') 
                count += 1
                config.bot.register_next_step_handler(msg, process_interests_step)
            elif count == 2:
                msg = config.bot.send_message(message.chat.id, 'Теперь точно так же напиши полные названия в кавычках и фамилии авторов (именно в таком порядке) твоих любимых книг через запятую. Если вы не хотите ничего указывать, напишите "-".', parse_mode='html', reply_markup=markup)
                count += 1
                config.bot.register_next_step_handler(msg, process_interests_step)
            else:
                # если count = 6, то уже комментарий писать надо
                msg = config.bot.send_message(message.chat.id, 'Заключительная часть вашей анкеты - это комментарий. Вы можете написать сюда всё, что угодно. Например, дополнительную информацию о себе или предпочтения в общении.', parse_mode='html', reply_markup=markup)
                config.bot.register_next_step_handler(msg, process_comment_step)
    except Exception:
        # на случай промаха пользователя
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        item = types.KeyboardButton('У меня уже есть анкета')
        markup.add(item)
        msg = config.bot.send_message(message.chat.id, 'Что-то пошло не так... Перепроверьте написание и попробуйте снова.', parse_mode='html', reply_markup=markup)
        config.bot.register_next_step_handler(msg, process_interests_step)

def process_comment_step(message):
    try:
        if message.text == 'У меня уже есть анкета':
            already_have(message)
        else:
            user_id = message.from_user.id 
            user = config.user_data[user_id]
            user.comment = message.text        
            config.bot.send_message(message.chat.id, 'Ваша анкета успешно добавлена.', parse_mode='html')
            database.new_user(user_id)

            markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
            item1 = types.KeyboardButton('Найти совпадения')
            item2 = types.KeyboardButton('Редактировать анкету')
            item3 = types.KeyboardButton('Удалить анкету')
            item4 = types.KeyboardButton('Найти профиль')
            item5 = types.KeyboardButton('Избранное')
            item6 = types.KeyboardButton('Добавить профиль в чёрный список')
            item7 = types.KeyboardButton('Удалить профиль из чёрного списка')
            item8 = types.KeyboardButton('Посмотреть взаимные избрания')
            markup.add(item1, item2, item3, item4, item5, item6, item7, item8)

            msg = config.bot.send_message(message.chat.id, 'Теперь вы можете на поле под вводом сообщения выбрать свои дальнейшие действия!', parse_mode='html', reply_markup=markup)
            config.bot.register_next_step_handler(msg, next_step)
    except Exception:
        msg = config.bot.send_message(message.chat.id, 'У вас уже есть анкета здесь. Вы хотели бы её удалить?', parse_mode='html', reply_markup=markup)
        config.bot.register_next_step_handler(msg, error)

def error(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    item1 = types.KeyboardButton('Да, удалить и создать новую')
    item2 = types.KeyboardButton('Оставить старую')
    markup.add(item1, item2)
    if message.text == 'Да, удалить и создать новую':
        database.edit_user(message.from_user.id)
        already_have(message)
    elif message.text == 'Оставить старую':
        already_have(message)
    else:
        msg = config.bot.send_message(message.chat.id, 'Что-то не так... У вас уже есть анкета здесь. Вы хотели бы её удалить?', parse_mode='html', reply_markup=markup)
        config.bot.register_next_step_handler(msg, error)

def already_have(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    item1 = types.KeyboardButton('Найти совпадения')
    item2 = types.KeyboardButton('Редактировать анкету')
    item3 = types.KeyboardButton('Удалить анкету')
    item4 = types.KeyboardButton('Найти профиль')
    item4 = types.KeyboardButton('Добавить профиль в чёрный список')
    item5 = types.KeyboardButton('Удалить профиль из чёрного списка')
    item6 = types.KeyboardButton('Посмотреть взаимные избрания')
    markup.add(item1, item2, item3, item4, item5, item6)
    msg = config.bot.send_message(message.chat.id, 'Ох, в таком случае я очень рад видеть вас снова! Что вы хотели бы сделать?', parse_mode='html', reply_markup=markup)
    config.bot.register_next_step_handler(msg, next_step)

def next_step(message):
    if message.text == 'Найти совпадения':
        config.bot.send_message(message.chat.id, 'Вас понял. Приступим!', parse_mode='html')
        config.bot.register_next_step_handler(message, friends.first_step)
    elif message.text == 'Редактировать анкету':
        # config.bot.send_message(message.chat.id, 'Вас понял. Приступим!', parse_mode='html')
        # config.bot.register_next_step_handler(message, edit.edit_profile)
        edit.edit_profile(message)
    elif message.text == 'Удалить анкету':
        config.bot.register_next_step_handler(message, delete.delete_profile)
    elif message.text == 'Найти профиль':
        config.bot.send_message(message.chat.id, 'Вас понял. Приступим!', parse_mode='html')
        config.bot.register_next_step_handler(message, database.find_profile)
    elif message.text == 'Избранное':
        config.bot.send_message(message.chat.id, 'Вас понял. Приступим!', parse_mode='html')
        config.bot.register_next_step_handler(message, friends.favorites)
    elif message.text == 'Добавить профиль в чёрный список':
        config.bot.register_next_step_handler(message, friends.blacklist_add)
    elif message.text == 'Удалить профиль из чёрного списка':
        config.bot.register_next_step_handler(message, delete.blacklist_remove)
    elif message.text == 'Посмотреть взаимные избрания':
        config.bot.register_next_step_handler(message, friends.mutual_favorites)
    else:
        msg = config.bot.send_message(message.chat.id, '''Я не уверен, что понял, что вы написали.
        Выберите на появившейся клавиатуре то, чем вы хотите сейчас заняться!''', parse_mode='html')
        config.bot.register_next_step_handler(msg, next_step)


config.bot.enable_save_next_step_handlers(delay=2)
config.bot.load_next_step_handlers()


if __name__ == '__main__':
     config.bot.infinity_polling()
