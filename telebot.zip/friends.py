import telebot 
from telebot import types
import login
import database
import config
import edit
import delete

person_list = []
mutual = []

# внимание: огромное число функций для поиска совпадений
def first_step(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    item1 = types.KeyboardButton('Создать список')
    item2 = types.KeyboardButton('Редактировать список')
    item3 = types.KeyboardButton('Найти совпадения')
    markup.add(item1, item2, item3)

    config.bot.send_message(message.chat.id, '''Первым делом нужно создать список интересов, по которому вы будете искать себе собеседников.
    Если у вас нет такого списка, то нажмите на клавиатуре или напишите "Создать список".
    Если вы хотите изменить его, то нажмите на клавиатуре или напишите "Редактировать список"
    Если вы не хотите ничего менять, то сразу переходим к поиску совпадений.''', parse_mode='html', reply_markup=markup)
    config.bot.register_next_step_handler(message, second_step)

def second_step(message):
    if message.text == 'Создать список' or message.text == 'Редактировать список':
        msg = config.bot.send_message(message.chat.id, 'Приступим!', parse_mode='html')
        config.bot.register_next_step_handler(msg, interests_list)
    elif message.text == 'Найти совпадения':
        msg = config.bot.send_message(message.chat.id, 'Тогда сразу к делу!', parse_mode='html')
        config.bot.register_next_step_handler(msg, find)
    else:
        msg = config.bot.send_message(message.chat.id, '''Я не уверен, что понял, что вы написали.
        Если у вас нет такого списка, то нажмите на клавиатуре или напишите "Создать список".
        Если вы хотите изменить его, то нажмите на клавиатуре или напишите "Редактировать список"
        Если вы не хотите ничего менять, то сразу переходим к поиску совпадений.''', parse_mode='html')
        config.bot.register_next_step_handler(msg, second_step)

# config.is_filled, чТо МоЖнО ПоНяТь По ПеРеВоДу, отвечает за наличие списка до этого, то есть это одна и та же функция для редактирования и для создания списка
# эта переменная меняется в файле database
def interests_list(message):
    user = config.user_data[message.from_user.id] 
    films = database.get_something('films', message.from_user.id)
    config.bot.send_message(message.chat.id, 'Начнём с фильмов. Вот текущий список ваших любимых фильмов.', parse_mode='html')
    config.bot.send_message(message.chat.id, films, parse_mode='html')
    if config.is_filled:
        config.bot.send_message(message.chat.id, 'А это текущий список фильмов для поиска собеседников.', parse_mode='html')
        config.bot.send_message(message.chat.id, database.get_something('films', message.from_user.id), parse_mode='html')
    films_list = config.bot.send_message(message.chat.id, '''Напишите фильмы, по которым бы хотели найти людей. 
    Если вы не хотите ничего указывать, напишите "-".''', parse_mode='html').text

    tv_shows = database.get_something('tv_shows', message.from_user.id)
    config.bot.send_message(message.chat.id, 'Перейдём к сериалам. Вот текущий список ваших любимых фильмов.', parse_mode='html')
    config.bot.send_message(message.chat.id, tv_shows, parse_mode='html')
    if config.is_filled:
        config.bot.send_message(message.chat.id, 'А это текущий список сериалов для поиска собеседников.', parse_mode='html')
        config.bot.send_message(message.chat.id, database.get_something('tv_shows', message.from_user.id), parse_mode='html')
    tv_shows_list = config.bot.send_message(message.chat.id, '''Напишите сериалы, по которым бы хотели найти людей. 
    Если вы не хотите ничего указывать, напишите "-".''', parse_mode='html').text

    books = database.get_something('books', message.from_user.id)
    config.bot.send_message(message.chat.id, 'На очереди у нас книги. Вот текущий список ваших любимых фильмов.', parse_mode='html')
    config.bot.send_message(message.chat.id, books, parse_mode='html')
    if config.is_filled:
        config.bot.send_message(message.chat.id, 'А это текущий список книг для поиска собеседников.', parse_mode='html')
        config.bot.send_message(message.chat.id, database.get_something('books', message.from_user.id), parse_mode='html')
    books_list = config.bot.send_message(message.chat.id, '''Напишите названия книг и фамилию их автора, по которым бы хотели найти людей.
    Если вы не хотите ничего указывать, напишите "-".''', parse_mode='html').text

    catroons = database.get_something('catroons', message.from_user.id)
    config.bot.send_message(message.chat.id, 'Теперь мультфильмы и мультсериалы. Вот текущий список ваших любимых фильмов.', parse_mode='html')
    config.bot.send_message(message.chat.id, catroons, parse_mode='html')
    if config.is_filled:
        config.bot.send_message(message.chat.id, 'А это текущий список мультфильмов и мульсериалов для поиска собеседников.', parse_mode='html')
        config.bot.send_message(message.chat.id, database.get_something('cartoons', message.from_user.id), parse_mode='html')
    cartoons_list = config.bot.send_message(message.chat.id, '''Напишите мультфильмы и мультсериалы, по которым бы хотели найти людей.
    Если вы не хотите ничего указывать, напишите "-".''', parse_mode='html').text

    anime = database.get_something('anime', message.from_user.id)
    config.bot.send_message(message.chat.id, 'А сейчас аниме и манга. Вот текущий список ваших любимых фильмов.', parse_mode='html')
    config.bot.send_message(message.chat.id, anime, parse_mode='html')
    if config.is_filled:
        config.bot.send_message(message.chat.id, 'А это текущий список аниме и манг для поиска собеседников.', parse_mode='html')
        config.bot.send_message(message.chat.id, database.get_something('anime', message.from_user.id), parse_mode='html')
    anime_list = config.bot.send_message(message.chat.id, '''Напишите названия аниме или манг, по которым бы хотели найти людей. 
    Если вы не хотите ничего указывать, напишите "-".''', parse_mode='html').text

    singers = database.get_something('singers', message.from_user.id)
    config.bot.send_message(message.chat.id, 'Последние в списке, но не по важности - музыкальные исполнители. Вот текущий список ваших любимых фильмов.', parse_mode='html')
    config.bot.send_message(message.chat.id, singers, parse_mode='html')
    if config.is_filled:
        config.bot.send_message(message.chat.id, 'А это текущий список музыкальных исполнителей для поиска собеседников.', parse_mode='html')
        config.bot.send_message(message.chat.id, database.get_something('singers', message.from_user.id), parse_mode='html')
    singers_list = config.bot.send_message(message.chat.id, '''Напишите псевдонимы, имена музыкальных исполнителей или названия музыкальных групп, по которым бы хотели найти совпадения. 
    Если вы не хотите ничего указывать, напишите "-".''', parse_mode='html').text

    lists = [films_list, tv_shows_list, books_list, cartoons_list, anime_list, singers_list]
    user.interests_list['interests_films'], user.interests_list['interests_tv_shows'], user.interests_list['interests_books'] = films_list, tv_shows_list, books_list
    user.interests_list['cartoons_list'], user.interests_list['anime_list'], user.interests_list['singers_list'] = cartoons_list, anime_list, singers_list
    if config.is_filled:
        database.update_interests(lists)
    else:
        database.interests(lists)
        config.is_filled = True
    config.bot.register_next_step_handler(message, find)


def find(message):
    global person_list
    id = message.from_user.id
    user = config.user_data[id] 
    films_list, tv_shows_list, books_list = user.interests_list['interests_films'], user.interests_list['interests_tv_shows'], user.interests_list['interests_books']
    cartoons_list, anime_list, singers_list = user.interests_list['cartoons_list'], user.interests_list['anime_list'], user.interests_list['singers_list']
    lists = [films_list, tv_shows_list, books_list, cartoons_list, anime_list, singers_list]
    people_interests = database.get_interests()
    count, matches = 0, 0
    is_match = False
    for person in people_interests:
        for kind in person:
            for interest in kind.split()[3:]:
                if interest in lists[count] and kind.split()[0] != id:
                    matches += 1
                    is_match = True
        if is_match:
            person_list.append([kind.split()[0], kind.split()[2], matches])
        count += 1
    person_list = sorted(person_list, key=lambda x: x[-1])
    if matches != 0:
        msg = config.bot.send_message(message.chat.id, '''Мы составили список людей с хотя бы одним совпадением с вашими интересами. Желаете просмотреть их профили?''', parse_mode='html')
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        item1 = types.KeyboardButton('Посмотреть профили')
        item2 = types.KeyboardButton('Редактировать список для поиска')
        markup.add(item1, item2)
        config.bot.register_next_step_handler(msg, next_step)
    else:
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        item1 = types.KeyboardButton('Редактировать список для поиска')
        item2 = types.KeyboardButton('Редактировать анкету')
        markup.add(item1, item2)
        msg= config.bot.send_message(message.chat.id, '''Вау, мы не нашли не одного совпадения с текущими пользователями...
        Это довольно странно, проверьте написание всех своих интересов, которые вы внесли в свою анкету и список для поиска.''', parse_mode='html', reply_markup=markup)
        config.bot.register_next_step_handler(msg, error_step)

def error_step(message):
    if message.text == 'Редактировать анкету': 
        msg = config.bot.send_message(message.chat.id, 'Приступим!', parse_mode='html')
        config.bot.register_next_step_handler(msg, edit.edit_profile)
    elif message.text == 'Редактировать список для поиска':
        msg = config.bot.send_message(message.chat.id, 'Приступим!', parse_mode='html')
        config.bot.register_next_step_handler(msg, interests_list)
    else:
        msg = config.bot.send_message(message.chat.id, '''Я не уверен, что понял, что вы написали.
        Если вы хотите отредактировать свою анкету, нажмите на кнопку под вводом сообщения или напишите "Редактировать анкету".
        Если же вы хотите поменять список интересов, нажмите на кнопку под вводом сообщения или напишите "Редактировать список для поиска".''', parse_mode='html')
        config.bot.register_next_step_handler(msg, error_step)

def next_step(message):
    if message.text == 'Посмотреть профили':
        for i in person_list:
            database.find_profile(i[1])
        person_list = []
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        item1 = types.KeyboardButton('Добавить в избранное')
        item2 = types.KeyboardButton('Редактировать список для поиска')
        markup.add(item1, item2)
        msg = config.bot.send_message(message.chat.id, '''Если кто-то заинтересовал вас, вы можете добавить его в избранное.
        Если же вы хотите поменять список интересов, вы можете его отредактировать.''', parse_mode='html')
        config.bot.register_next_step_handler(msg, next_step_2)
    elif message.text == 'Редактировать список для поиска':
        msg = config.bot.send_message(message.chat.id, 'Приступим!', parse_mode='html')
        config.bot.register_next_step_handler(msg, interests_list)
    else:
        msg = config.bot.send_message(message.chat.id, '''Я не уверен, что понял, что вы написали.
        Если вы хотите просмотреть профили потенциальных друзей, нажмите на кнопку под вводом сообщения или напишите "Посмотреть профили".
        Если же вы хотите поменять список интересов, нажмите на кнопку под вводом сообщения или напишите "Редактировать список для поиска".''', parse_mode='html')
        config.bot.register_next_step_handler(msg, next_step)

def next_step_2(message):
    if message.text == 'Добавить в избранное':
        msg = config.bot.send_message(message.chat.id, 'Приступим!', parse_mode='html')
        config.bot.register_next_step_handler(msg, update_favorites)
    elif message.text == 'Редактировать список для поиска':
        msg = config.bot.send_message(message.chat.id, 'Приступим!', parse_mode='html')
        config.bot.register_next_step_handler(msg, interests_list)
    else:
        msg = config.bot.send_message(message.chat.id, '''Я не уверен, что понял, что вы написали.
        Если кто-то заинтересовал вас, нажмите на кнопку под вводом сообщения или напишите "Добавить в избранное".
        Если же вы хотите поменять список интересов, нажмите на кнопку под вводом сообщения или напишите "Редактировать список для поиска".''', parse_mode='html')
        config.bot.register_next_step_handler(msg, next_step_2)

# внимание: огромное число функций на поиск совпадений закончилось
def favorites(message):
    # функция, показывающая всех людей в Избранном
    people = database.favorites(message)
    config.bot.send_message(message.chat.id, 'Вот кодовые имена людей, которые находятся у вас в Избранном: {}'.format(', '.join(people)), parse_mode='html')
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    item1 = types.KeyboardButton('Посмотреть профиль одного из них')
    item2 = types.KeyboardButton('Посмотреть профили всех людей в избранном')
    item3 = types.KeyboardButton('Добавить в избранное')
    item4 = types.KeyboardButton('Удалить из избранного')
    item5 = types.KeyboardButton('Назад')
    markup.add(item1, item2, item3, item4, item5)
    msg = config.bot.send_message(message.chat.id, 'Выберите ваши дальнейшие действия.', parse_mode='html', reply_markup=markup)
    config.bot.register_next_step_handler(msg, favorites_next_step)

def favorites_next_step(message):
    if message.text == 'Посмотреть профиль одного из них':
        msg = config.bot.send_message(message.chat.id, 'Приступим! Профиль какого человека мы смотрим?', parse_mode='html')
        config.bot.register_next_step_handler(msg, database.find_profile)
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        item = types.KeyboardButton('Назад')
        markup.add(item)
        config.bot.register_next_step_handler(message, favorites_next_step_2)
    elif message.text == 'Посмотреть профили всех людей в избранном':
        config.bot.send_message(message.chat.id, 'Приступим!', parse_mode='html')
        people = database.favorites(message)
        for i in people:
            config.bot.register_next_step_handler(i, database.find_profile)
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        item = types.KeyboardButton('Назад')
        markup.add(item)
        config.bot.register_next_step_handler(message, favorites_next_step_2)
    elif message.text == 'Добавить в избранное':
        config.bot.register_next_step_handler(message, update_favorites)
    elif message.text == 'Удалить из избранного':
        config.bot.register_next_step_handler(message, delete.delete_favorites)
    elif message.text == 'Назад':
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        item1 = types.KeyboardButton('Найти совпадения')
        item2 = types.KeyboardButton('Редактировать анкету')
        item3 = types.KeyboardButton('Удалить анкету')
        item4 = types.KeyboardButton('Найти профиль')
        item5 = types.KeyboardButton('Избранное')
        item6 = types.KeyboardButton('Добавить профиль в чёрный список')
        item7 = types.KeyboardButton('Удалить профиль из чёрного списка')
        item8 = types.KeyboardButton('Посмотреть взаимные избрания')
        markup.add(item1, item2, item3, item4, item5, item6, item7, item8)
        msg = config.bot.send_message(message.chat.id, 'Что мы тогда будем делать?', parse_mode='html', reply_markup=markup)
        config.bot.register_next_step_handler(msg, login.next_step)
    else:
        msg = config.bot.send_message(message.chat.id, '''Я не уверен, что понял, что вы написали.
        Если кто-то заинтересовал вас, нажмите на кнопку под вводом сообщения или напишите "Добавить в избранное".
        Если же вы хотите поменять список интересов, нажмите на кнопку под вводом сообщения или напишите "Редактировать список для поиска".''', parse_mode='html')
        config.bot.register_next_step_handler(msg, next_step_2)
    
def favorites_next_step_2(message):
    if message.text == 'Назад':
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        item1 = types.KeyboardButton('Найти совпадения')
        item2 = types.KeyboardButton('Редактировать анкету')
        item3 = types.KeyboardButton('Удалить анкету')
        item4 = types.KeyboardButton('Найти профиль')
        item5 = types.KeyboardButton('Избранное')
        item6 = types.KeyboardButton('Добавить профиль в чёрный список')
        item7 = types.KeyboardButton('Удалить профиль из чёрного списка')
        item8 = types.KeyboardButton('Посмотреть взаимные избрания')
        markup.add(item1, item2, item3, item4, item5, item6, item7, item8)
        msg = config.bot.send_message(message.chat.id, 'Что мы тогда будем делать?', parse_mode='html', reply_markup=markup)
        config.bot.register_next_step_handler(msg, login.next_step)
    else:
        msg = config.bot.send_message(message.chat.id, '''Я не уверен, что понял, что вы написали.
        Если кто-то заинтересовал вас, нажмите на кнопку под вводом сообщения или напишите "Добавить в избранное".
        Если же вы хотите поменять список интересов, нажмите на кнопку под вводом сообщения или напишите "Редактировать список для поиска".''', parse_mode='html')
        config.bot.register_next_step_handler(msg, next_step_2)

def update_favorites(message):
    try:
        msg = config.bot.send_message(message.chat.id, 'Напишите кодовые имена в точности, как у тех пользователей, которых вы хотели бы добавить в избранное, через запятую.', parse_mode='html')
        codes = msg.text
        if ', '.count(codes) == 0:
            raise Exception
        codes = codes.split()
        for i in codes:
            if i not in login.code_names:
                raise Exception
        database.update_favorites(', '.join(codes), message.from_user.id)
    except Exception:
        msg = config.bot.send_message(message.chat.id, 'Что-то пошло не так... Перепроверьте написание и повторите попытку', parse_mode='html')
        config.bot.register_next_step_handler(msg, next_step_2)

def mutual_favorites(message):
    global mutual
    people = database.get_something('favorites', message.from_user.id)
    user = config.user_data[message.from_user.id]
    person_favorites = []
    for person in people:
        id = database.get_id(person)
        person_favorites = database.get_something('favorites', id)
        if user in person_favorites:
            mutual.append(person)
    if len(mutual) == 0:
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        item1 = types.KeyboardButton('Найти совпадения')
        item2 = types.KeyboardButton('Редактировать анкету')
        item3 = types.KeyboardButton('Удалить анкету')
        item4 = types.KeyboardButton('Найти профиль')
        item5 = types.KeyboardButton('Избранное')
        item6 = types.KeyboardButton('Добавить профиль в чёрный список')
        item7 = types.KeyboardButton('Удалить профиль из чёрного списка')
        item8 = types.KeyboardButton('Посмотреть взаимные избрания')
        markup.add(item1, item2, item3, item4, item5, item6, item7, item8)
        msg = config.bot.send_message(message.chat.id, '''К сожалению, пока что у вас нет взаимных избраний, но они обязательно появятся! 
        А пока вы ждёте, вы можете сделать что-нибудь ещё!''', parse_mode='html', reply_markup=markup)
        config.bot.register_next_step_handler(msg, login.next_step)
    else:
        msg = 'Ура, я нашёл! У вас есть взаимные избрания:'
        for i in mutual:
            id = database.get_id(i)
            msg += '\n' + i + ': ' + config.user_data[id].username
        mutual = []
        config.bot.send_message(message.chat.id, msg, parse_mode='html')
        config.bot.send_message(message.chat.id, '''Если вы хотите продолжить поиск, напишите "ДА". 
        Если же нет, приятного общения с новыми друзьями, а я всегда буду ждать вас!''', parse_mode='html')
        config.bot.register_next_step_handler(msg, after)

def blacklist_add(message):
    msg = config.bot.send_message(message.chat.id, 'Напишите кодовые имена тех людей, которых вы бы хотели добавить в чёрный список, через запятую.', parse_mode='html')
    codes = msg.text
    msg = config.bot.send_message(message.chat.id, 'Вы уверены, что хотите добавить этих людей в чёрный список?? Напишите "ДА" большими буквами, чтобы подтвердить это, или "НЕТ" в обратном случае.', parse_mode='html')
    if msg.text == 'ДА':
        msg = config.bot.send_message(message.chat.id, 'Я выполнил вашу просьбу. Что будем делать дальше?', parse_mode='html')
        database.delete_blacklist(codes, msg.chat.id)
    elif msg.text == 'НЕТ':
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        item1 = types.KeyboardButton('Найти совпадения')
        item2 = types.KeyboardButton('Редактировать анкету')
        item3 = types.KeyboardButton('Удалить анкету')
        item4 = types.KeyboardButton('Найти профиль')
        item5 = types.KeyboardButton('Избранное')
        item6 = types.KeyboardButton('Добавить профиль в чёрный список')
        item7 = types.KeyboardButton('Удалить профиль из чёрного списка')
        item8 = types.KeyboardButton('Посмотреть взаимные избрания')
        markup.add(item1, item2, item3, item4, item5, item6, item7, item8)
        msg = config.bot.send_message(message.chat.id, 'Ладненько, а что же я должен сделать?', parse_mode='html', reply_markup=markup)
        config.bot.register_next_step_handler(msg, login.next_step)
    else:
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        item1 = types.KeyboardButton('Найти совпадения')
        item2 = types.KeyboardButton('Редактировать анкету')
        item3 = types.KeyboardButton('Удалить анкету')
        item4 = types.KeyboardButton('Найти профиль')
        item5 = types.KeyboardButton('Избранное')
        item6 = types.KeyboardButton('Добавить профиль в чёрный список')
        item7 = types.KeyboardButton('Удалить профиль из чёрного списка')
        item8 = types.KeyboardButton('Посмотреть взаимные избрания')
        markup.add(item1, item2, item3, item4, item5, item6, item7, item8)
        msg = config.bot.send_message(message.chat.id, 'Что-то пошло не так...', parse_mode='html', reply_markup=markup)
        config.bot.register_next_step_handler(msg, blacklist_add)

def after(message):
    if message.text == 'ДА':
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        item1 = types.KeyboardButton('Найти совпадения')
        item2 = types.KeyboardButton('Редактировать анкету')
        item3 = types.KeyboardButton('Удалить анкету')
        item4 = types.KeyboardButton('Найти профиль')
        item5 = types.KeyboardButton('Избранное')
        item6 = types.KeyboardButton('Добавить профиль в чёрный список')
        item7 = types.KeyboardButton('Удалить профиль из чёрного списка')
        item8 = types.KeyboardButton('Посмотреть взаимные избрания')
        markup.add(item1, item2, item3, item4, item5, item6, item7, item8)
        msg = config.bot.send_message(message.chat.id, 'Вау, вы всё ещё со мной? Ладненько, а что же я должен сделать?', parse_mode='html', reply_markup=markup)
        config.bot.register_next_step_handler(msg, login.next_step)
    else:
        config.bot.send_message(message.chat.id, 'Я не понимаю, что тут написано. Напишите "ДА", если захотите ко мне обратиться.', parse_mode='html', reply_markup=markup)
        config.bot.register_next_step_handler(msg, after)