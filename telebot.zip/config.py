import telebot

TOKEN = '1444135700:AAHZVEU8nF1DiZmrW2b9eSybhh9XfkpdYLo'
bot = telebot.TeleBot(TOKEN)
is_filled = False
user_data = {}