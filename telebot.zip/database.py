import sqlite3
import login
import config


def info(id, col):
    con = sqlite3.connect("users.sqlite")
    cur = con.cursor()
    result = cur.execute('''SELECT ? from data
    WHERE id = ?''', (col, id)).fetchall()
    con.close()
    return list(result)

def new_user(id):
    con = sqlite3.connect("users.sqlite")
    cur = con.cursor()
    user = config.user_data[id]
    cur.execute('''INSERT INTO data (id, name, username, code, status, films, tv_shows, books, cartoons, anime, singers, comment)
    VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''', (str(id), user.name, user.username, user.code, user.status, user.interests['films'], user.interests['tv_shows'], user.interests['books'], 
    user.interests['cartoons'], user.interests['anime'], user.interests['singers'], user.comment)).fetchall()
    con.commit()
    con.close()

def edit_user(id):
    con = sqlite3.connect("users.sqlite")
    cur = con.cursor()
    user = config.user_data[id]
    cur.execute('''UPDATE data
    SET name = ? AND status = ? AND films = ? AND tv_shows = ? AND books = ? AND cartoons = ? AND anime = ? AND singers = ? AND comment = ?
    WHERE id = ?''', (user.name, user.status, user.interests['films'], user.interests['tv_shows'], user.interests['books'], 
    user.interests['cartoons'], user.interests['anime'], user.interests['singers'], user.comment, id)).fetchall()
    con.commit()
    con.close()
    
def delete_user(id):
    con = sqlite3.connect("users.sqlite")
    cur = con.cursor()
    cur.execute('''DELETE from data 
    where id = ?''', (id)).fetchall()
    con.commit()
    con.close()

def find_profile(message):
    con = sqlite3.connect("users.sqlite")
    cur = con.cursor()
    code = message.text
    id = cur.execute('''SELECT id from data
    WHERE code = ''', (code)).fetchall()
    con.close()
    show_profile(message, id)

def show_profile(message, id):
    user = config.user_data[id]
    profile = user.name + ', ' + user.status + '\n' + 'Кодовое имя: ' + user.code
    if user.interests['films'] != '-':
        profile += '\n' + 'Люблю такие фильмы: {}'.format(', '.join(user.interests['films']))
    if user.interests['films'] != '-':
        profile += '\n' + 'Люблю такие сериалы: {}'.format(', '.join(user.interests['tv_shows']))
    if user.interests['films'] != '-':
        profile += '\n' + 'Люблю такие книги: {}'.format(', '.join(user.interests['books']))
    if user.interests['films'] != '-':
        profile += '\n' + 'Люблю такие мультфильмы и мультсериалы: {}'.format(', '.join(user.interests['cartoons']))
    if user.interests['films'] != '-':
        profile += '\n' + 'Люблю такие аниме и манги: {}'.format(', '.join(user.interests['anime']))
    if user.interests['films'] != '-':
        profile += '\n' + 'Люблю таких музыкальных исполнителей: {}'.format(', '.join(user.interests['singers']))
    profile += 'P.S. ' + user.comment
    config.bot.send_message(message.chat.id, profile, parse_mode='html')
    
def get_something(parametr, id):
    con = sqlite3.connect("users.sqlite")
    cur = con.cursor()
    result = cur.execute('''SELECT ? from data
    WHERE id = ?''', (parametr, id)).fetchall()
    con.close()
    return ' '.join(*result)

def get_id(code):
    con = sqlite3.connect("users.sqlite")
    cur = con.cursor()
    result = cur.execute('''SELECT id from data
    WHERE code = ?''', (code)).fetchall()
    con.close()
    return ' '.join(*result)

def interests(lists):
    con = sqlite3.connect("users.sqlite")
    cur = con.cursor()
    cur.execute('INSERT INTO data(interests_films, interests_tv_shows, interests_books, interests_cartoons, interests_anime, interests_singers) VALUES(?, ?, ?, ?, ?, ?)', 
    (' '.join(lists[0]), ' '.join(lists[1]), ' '.join(lists[2]), ' '.join(lists[3]), ' '.join(lists[4]), ' '.join(lists[5]))).fetchall()
    con.commit()
    con.close()

def update_interests(lists):
    con = sqlite3.connect("users.sqlite")
    cur = con.cursor()
    cur.execute('''UPDATE data
    SET interests_films = ? AND interests_tv_shows = ? AND interests_books = ? AND interests_cartoons = ? AND interests_anime = ? AND interests_singers = ?
    WHERE id = ?''', (lists[0], lists[1], lists[2], lists[3], lists[4], lists[5], id)).fetchall()
    con.commit()
    con.close()

def get_interests():
    con = sqlite3.connect("users.sqlite")
    cur = con.cursor()
    people = cur.execute('SELECT id, name, code, interests_films, interests_tv_shows, interests_books, interests_cartoons, interests_anime, interests_singers from data').fetchall()
    people = list(*people)
    people_interests = []
    for i in people:
        i = list(*i)
        people_interests += [i]
    con.close()
    return people_interests

def favorites(message):
    con = sqlite3.connect("users.sqlite")
    cur = con.cursor()
    people = cur.execute('''SELECT favorites from data
    WHERE id = ?''', (message.from_user.id)).fetchall()
    people = list(*people)
    con.close()
    return people
    
def update_favorites(codes, self_id):
    con = sqlite3.connect("users.sqlite")
    cur = con.cursor()
    favorite = get_something('favorites', self_id)
    cur.execute('''UPDATE data
    SET favorite = ?
    WHERE id = ?''', (favorite + ', ' + codes, self_id)).fetchall()
    con.commit()
    con.close()

def delete_favorites(codes, self_id):
    con = sqlite3.connect("users.sqlite")
    cur = con.cursor()
    favorite = get_something('favorites', self_id).split()
    i = 0
    while i < len(favorite):
        if favorite[i] in codes:
            del favorite[i]
        i += 1
    cur.execute('''UPDATE data
    SET favorites = ?
    WHERE id = ?''', (', '.join(favorite), self_id)).fetchall()
    con.commit()
    con.close()

def update_blacklist(codes, self_id):
    con = sqlite3.connect("users.sqlite")
    cur = con.cursor()
    blacklist = get_something('blacklist', self_id)
    cur.execute('''UPDATE data
    SET blacklist = ?
    WHERE id = ?''', (blacklist + ', ' + codes, self_id)).fetchall()
    con.commit()
    con.close()

def delete_blacklist(codes, self_id):
    con = sqlite3.connect("users.sqlite")
    cur = con.cursor()
    blacklist = get_something('blacklist', self_id).split(', ')
    i = 0
    while i < len(blacklist):
        if blacklist[i] in codes:
            del blacklist[i]
        else:
            i += 1
    cur.execute('''UPDATE data
    SET blacklist = ?
    WHERE id = ?''', (', '.join(blacklist), self_id)).fetchall()
    con.commit()
    con.close()
