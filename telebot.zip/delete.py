import telebot 
from telebot import types
import config
import database
import login

# файл для того, чтобы что-то удалять: профиль, человека из чс и тп

def delete_profile(message):
    # эта функция удаляет профиль, можно по названию понять
    msg = config.bot.send_message(message.chat.id, 'Вы уверены, что хотите удалить свой аккаунт?? Напишите "УДАЛИТЬ" большими буквами, чтобы подтвердить это, или "НЕТ", если не хотите удалять.', parse_mode='html')
    if msg.text == 'УДАЛИТЬ':
        msg = config.bot.send_message(message.chat.id, 'Эх, жаль расставаться с вами. Надеюсь, вы нашли, с кем поговорить... Если хотите вернуться, наши двери открыты для вас, просто напишите "/start"!', parse_mode='html')
        database.delete_user(msg.from_user.id)
    elif msg.text == 'НЕТ':
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        item1 = types.KeyboardButton('Найти совпадения')
        item2 = types.KeyboardButton('Редактировать анкету')
        item3 = types.KeyboardButton('Удалить анкету')
        item4 = types.KeyboardButton('Найти профиль')
        item5 = types.KeyboardButton('Избранное')
        item6 = types.KeyboardButton('Добавить профиль в чёрный список')
        item7 = types.KeyboardButton('Удалить профиль из чёрного списка')
        item8 = types.KeyboardButton('Посмотреть взаимные избрания')
        markup.add(item1, item2, item3, item4, item5, item6, item7, item8)
        msg = config.bot.send_message(message.chat.id, 'Фууууух, я уж боялся вас потерять. Тогда давайте продолжим поиск ваших будущих друзей. Выбирайте дальнейший курс корабля на клавиатуре ниже!.', parse_mode='html')
        config.bot.register_next_step_handler(msg, login.next_step)
    else:
        msg = config.bot.send_message(message.chat.id, 'Что-то пошло не так...', parse_mode='html')
        config.bot.register_next_step_handler(msg, delete_profile)

def delete_favorites(message):
    msg = config.bot.send_message(message.chat.id, 'Напишите кодовые имена тех людей, которых вы бы хотели удалить из Избранного, через запятую.', parse_mode='html')
    codes = msg.text
    msg = config.bot.send_message(message.chat.id, 'Вы уверены, что хотите удалить этих людей из Избранного?? Напишите "УДАЛИТЬ" большими буквами, чтобы подтвердить это, или "НЕТ", если не хотите удалять.', parse_mode='html')
    if msg.text == 'УДАЛИТЬ':
        msg = config.bot.send_message(message.chat.id, 'Я выполнил вашу просьбу. Что будем делать дальше?', parse_mode='html')
        database.delete_favorites(codes, msg.from_user.id)
    elif msg.text == 'НЕТ':
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        item1 = types.KeyboardButton('Найти совпадения')
        item2 = types.KeyboardButton('Редактировать анкету')
        item3 = types.KeyboardButton('Удалить анкету')
        item4 = types.KeyboardButton('Найти профиль')
        item5 = types.KeyboardButton('Избранное')
        item6 = types.KeyboardButton('Добавить профиль в чёрный список')
        item7 = types.KeyboardButton('Удалить профиль из чёрного списка')
        item8 = types.KeyboardButton('Посмотреть взаимные избрания')
        markup.add(item1, item2, item3, item4, item5, item6, item7, item8)
        msg = config.bot.send_message(message.chat.id, 'Ну тогда хорошо. Что будем делать дальше?', parse_mode='html')
        config.bot.register_next_step_handler(msg, login.next_step)
    else:
        msg = config.bot.send_message(message.chat.id, 'Что-то пошло не так...', parse_mode='html')
        config.bot.register_next_step_handler(msg, delete_favorites)

def blacklist_remove(message):
    msg = config.bot.send_message(message.chat.id, 'Напишите кодовые имена тех людей, которых вы бы хотели удалить из чёрного списка, через запятую.', parse_mode='html')
    codes = msg.text
    msg = config.bot.send_message(message.chat.id, 'Вы уверены, что хотите удалить этих людей из чёрного списка?? Напишите "УДАЛИТЬ" большими буквами, чтобы подтвердить это, или "НЕТ", если не хотите удалять.', parse_mode='html')
    if msg.text == 'УДАЛИТЬ':
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        item1 = types.KeyboardButton('Найти совпадения')
        item2 = types.KeyboardButton('Редактировать анкету')
        item3 = types.KeyboardButton('Удалить анкету')
        item4 = types.KeyboardButton('Найти профиль')
        item5 = types.KeyboardButton('Избранное')
        item6 = types.KeyboardButton('Добавить профиль в чёрный список')
        item7 = types.KeyboardButton('Удалить профиль из чёрного списка')
        item8 = types.KeyboardButton('Посмотреть взаимные избрания')
        markup.add(item1, item2, item3, item4, item5, item6, item7, item8)
        msg = config.bot.send_message(message.chat.id, 'Этот человек успешно удалён из чёрного списка. Каковы дальнейшие действия?', parse_mode='html')
        database.delete_blacklist(codes, msg.from_user.id)
        config.bot.register_next_step_handler(msg, login.next_step)
    elif msg.text == 'НЕТ':
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        item1 = types.KeyboardButton('Найти совпадения')
        item2 = types.KeyboardButton('Редактировать анкету')
        item3 = types.KeyboardButton('Удалить анкету')
        item4 = types.KeyboardButton('Найти профиль')
        item5 = types.KeyboardButton('Избранное')
        item6 = types.KeyboardButton('Добавить профиль в чёрный список')
        item7 = types.KeyboardButton('Удалить профиль из чёрного списка')
        item8 = types.KeyboardButton('Посмотреть взаимные избрания')
        markup.add(item1, item2, item3, item4, item5, item6, item7, item8)
        msg = config.bot.send_message(message.chat.id, 'Тогда всё остаётся неизменным. Выберите ваши дальнейшие действия.', parse_mode='html')
        config.bot.register_next_step_handler(msg, login.next_step)
    else:
        msg = config.bot.send_message(message.chat.id, 'Что-то пошло не так...', parse_mode='html')
        config.bot.register_next_step_handler(msg, blacklist_remove)