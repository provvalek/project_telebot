import telebot 
from telebot import types
import config
import database
import login

def edit_profile(message):
    try:
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        item1 = types.KeyboardButton('Имя')
        item2 = types.KeyboardButton('Статус')
        item3 = types.KeyboardButton('Фильмы')
        item4 = types.KeyboardButton('Сериалы')
        item5 = types.KeyboardButton('Книги')
        item6 = types.KeyboardButton('Мультики')
        item7 = types.KeyboardButton('Аниме и манга')
        item8 = types.KeyboardButton('Музыкальные исполнители')
        item9 = types.KeyboardButton('Комментарий')
        markup.add(item1, item2, item3, item4, item5, item6, item7, item8, item9)
        msg = config.bot.send_message(message.chat.id, 'Выбери то поле, которое ты бы сейчас отредактировал(а).', parse_mode='html', reply_markup=markup)
        config.bot.register_next_step_handler(msg, edit_next)
    except Exception:
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        item = types.KeyboardButton('Да')
        markup.add(item)
        msg = config.bot.send_message(message.chat.id, 'Похоже, что у вас ещё нет аккаунта. Хотите зарегистрироваться?', parse_mode='html', reply_markup=markup)
        config.bot.register_next_step_handler(msg, edit_error)

def edit_next(message):
    try:
        if message.text == 'Имя':
            name = database.info(msg.from_user.id, 'name')  
            config.bot.send_message(message.chat.id, 'Вот то, что записано у тебя в данный момент:', parse_mode='html')
            config.bot.send_message(message.chat.id, name, parse_mode='html')
            msg = config.bot.send_message(message.chat.id, 'Напиши свой новый вариант имени! (имя-фамилия через пробел!!)', parse_mode='html')

            user = config.user_data[msg.from_user.id]
            user.name = msg.text

            database.edit_user(msg.from_user.id)
        elif message.text == 'Статус':
            status = database.info(msg.from_user.id, 'status')
            config.bot.send_message(message.chat.id, 'Вот то, что записано у тебя в данный момент:', parse_mode='html')
            config.bot.send_message(message.chat.id, status, parse_mode='html')
            msg = config.bot.send_message(message.chat.id, 'Напиши свой новый статус!', parse_mode='html')
            
            user = config.user_data[msg.from_user.id]
            user.status = msg.text

            database.edit_user(msg.from_user.id)
        elif message.text == 'Фильмы':
            films = database.info(msg.from_user.id, 'films')
            config.bot.send_message(message.chat.id, 'Вот то, что записано у тебя в данный момент:', parse_mode='html')
            config.bot.send_message(message.chat.id, films, parse_mode='html')
            msg = config.bot.send_message(message.chat.id, 'Напиши свой новый список любимых фильмов! (через запятую в кавычках!!)', parse_mode='html')

            user = config.user_data[msg.from_user.id]
            user.films = msg.text

            database.edit_user(msg.from_user.id)
        elif message.text == 'Сериалы':
            tw_shows = database.info(msg.from_user.id, 'tw_shows')
            config.bot.send_message(message.chat.id, 'Вот то, что записано у тебя в данный момент:', parse_mode='html')
            config.bot.send_message(message.chat.id, tw_shows, parse_mode='html')
            msg = config.bot.send_message(message.chat.id, 'Напиши свой новый список любимых сериалов! (через запятую в кавычках!!)', parse_mode='html')

            user = config.user_data[msg.from_user.id]
            user.tw_shows = msg.text

            database.edit_user(msg.from_user.id)
        elif message.text == 'Книги':
            books = database.info(msg.from_user.id, 'books')
            config.bot.send_message(message.chat.id, 'Вот то, что записано у тебя в данный момент:', parse_mode='html')
            config.bot.send_message(message.chat.id, books, parse_mode='html')
            msg = config.bot.send_message(message.chat.id, 'Напиши свой новый список любимых книг! (через запятую в кавычках, не забываем фамилию автора после названия книги!!)', parse_mode='html')

            user = config.user_data[msg.from_user.id]
            user.books = msg.text

            database.edit_user(msg.from_user.id)
        elif message.text == 'Мультики':
            cartoons = database.info(msg.from_user.id, 'cartoons')
            config.bot.send_message(message.chat.id, 'Вот то, что записано у тебя в данный момент:', parse_mode='html')
            config.bot.send_message(message.chat.id, cartoons, parse_mode='html')
            msg = config.bot.send_message(message.chat.id, 'Напиши свой новый список любимых мультфильмов и мультсериалов! (через запятую в кавычках!!)', parse_mode='html')

            user = config.user_data[msg.from_user.id]
            user.cartoons = msg.text

            database.edit_user(msg.from_user.id)
        elif message.text == 'Аниме и манга':
            anime = database.info(msg.from_user.id, 'anime')
            config.bot.send_message(message.chat.id, 'Вот то, что записано у тебя в данный момент:', parse_mode='html')
            config.bot.send_message(message.chat.id, anime, parse_mode='html')
            msg = config.bot.send_message(message.chat.id, 'Напиши свой новый список любимых аниме и манг! (через запятую в кавычках!!)', parse_mode='html')

            user = config.user_data[msg.from_user.id]
            user.anime = msg.text

            database.edit_user(msg.from_user.id)
        elif message.text == 'Музыкальные исполнители':
            singers = database.info(msg.from_user.id, 'singers')
            config.bot.send_message(message.chat.id, 'Вот то, что записано у тебя в данный момент:', parse_mode='html')
            config.bot.send_message(message.chat.id, singers, parse_mode='html')
            msg = config.bot.send_message(message.chat.id, 'Напиши свой новый список любимых музыкальных исполнителей! (через запятую самые популярные имена, псевдонимы и т.п.!!)', parse_mode='html')

            user = config.user_data[msg.from_user.id]
            user.singers = msg.text

            database.edit_user(msg.from_user.id)
        elif message.text == 'Комментарий':
            comment = database.info(msg.from_user.id, 'comment')
            config.bot.send_message(message.chat.id, 'Вот то, что записано у тебя в данный момент:', parse_mode='html')
            config.bot.send_message(message.chat.id, comment, parse_mode='html')
            msg = config.bot.send_message(message.chat.id, '', parse_mode='html')

            user = config.user_data[msg.from_user.id]
            user.comment = msg.text

            config.bot.send_message(message.chat.id, 'Напиши свой новый вариант комментария!', parse_mode='html')
            database.edit_user(msg.from_user.id)
        else:
            msg = config.bot.send_message(message.chat.id, 'Что-то пошло не так... ', parse_mode='html')
            config.bot.register_next_step_handler(msg, edit_profile)
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        item1 = types.KeyboardButton('Да')
        item2 = types.KeyboardButton('Нет')
        markup.add(item1, item2)
        msg = config.bot.send_message(message.chat.id, 'Ваш запрос выполнен. Продолжаем редактирование?', parse_mode='html', reply_markup=markup)
        config.bot.register_next_step_handler(msg, next_step)
    except Exception:
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        item = types.KeyboardButton('Да')
        markup.add(item)
        msg = config.bot.send_message(message.chat.id, 'Похоже, что у вас ещё нет аккаунта. Хотите зарегистрироваться?', parse_mode='html', reply_markup=markup)
        config.bot.register_next_step_handler(msg, edit_error)

def edit_error(message):
    if message.text == 'Да':
        login.process_name_step(message)
    else:
        msg = config.bot.send_message(message.chat.id, 'Если захотите зарегистрироваться, напишите "Да", я всегда буду ждать вас!', parse_mode='html')
        config.bot.register_next_step_handler(msg, edit_error)

def next_step(message):
    if message.text == 'Да':
        config.bot.register_next_step_handler(message, edit_profile)
    elif message.test == 'Нет':
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        item1 = types.KeyboardButton('Найти совпадения')
        item2 = types.KeyboardButton('Редактировать анкету')
        item3 = types.KeyboardButton('Удалить анкету')
        item4 = types.KeyboardButton('Найти профиль')
        item4 = types.KeyboardButton('Добавить профиль в чёрный список')
        item5 = types.KeyboardButton('Удалить профиль из чёрного списка')
        item6 = types.KeyboardButton('Посмотреть взаимные избрания')
        markup.add(item1, item2, item3, item4, item5, item6)

        msg = config.bot.send_message(message.chat.id, 'Теперь вы можете на поле под вводом сообщения выбрать свои дальнейшие действия!', parse_mode='html', reply_markup=markup)
        config.bot.register_next_step_handler(msg, login.next_step)
    else:
        msg = config.bot.send_message(message.chat.id, 'Что-то пошло не так... Если вы хотите продолжить редактирование профиля, то напишите "Да", иначе напишите "Нет".', parse_mode='html')
        config.bot.register_next_step_handler(msg, next_step)


